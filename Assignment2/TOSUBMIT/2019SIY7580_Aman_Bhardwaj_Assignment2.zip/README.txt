Please use Jupyter Notebook.I have included .py file of the same as well.

0. MAKE SURE YOU HAVE GMPY2 Package Installed. If you are unable to include module. then install the module from      whl included in the directory
1. Place message in message.txt file
2. Vigenere Cipher key in vigenere_key.txt files